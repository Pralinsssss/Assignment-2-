import os
import pandas as pd
import numpy as np

# Folder path containing all CSVs
temp_folder = "temperatures"

# Define Australian seasons
seasons = {
    "Summer": ["December", "January", "February"],
    "Autumn": ["March", "April", "May"],
    "Winter": ["June", "July", "August"],
    "Spring": ["September", "October", "November"]
}

def load_all_data(folder):
    all_data = []
    for file in os.listdir(folder):
        if file.endswith(".csv"):
            df = pd.read_csv(os.path.join(folder, file))
            all_data.append(df)
    return pd.concat(all_data, ignore_index=True)

def calculate_seasonal_average(df):
    results = {}
    for season, months in seasons.items():
        season_values = df[months].values.flatten()
        season_values = season_values[~np.isnan(season_values)]
        results[season] = round(np.mean(season_values), 2)
    with open("average_temp.txt", "w") as f:
        for season, avg in results.items():
            f.write(f"{season}: {avg}°C\n")

def find_largest_temp_range(df):
    station_ranges = {}
    month_cols = [col for col in df.columns if col not in ["STATION_NAME", "STN_ID", "LAT", "LON"]]
    for _, row in df.iterrows():
        temps = row[month_cols].values.astype(float)
        temps = temps[~np.isnan(temps)]
        if len(temps) > 0:
            temp_range = np.max(temps) - np.min(temps)
            station_ranges[row["STATION_NAME"]] = (
                round(temp_range, 2), round(np.max(temps), 2), round(np.min(temps), 2)
            )
    max_range = max([v[0] for v in station_ranges.values()])
    with open("largest_temp_range_station.txt", "w") as f:
        for station, (rng, tmax, tmin) in station_ranges.items():
            if rng == max_range:
                f.write(f"{station}: Range {rng}°C (Max: {tmax}°C, Min: {tmin}°C)\n")

def find_temperature_stability(df):
    std_devs = {}
    month_cols = [col for col in df.columns if col not in ["STATION_NAME", "STN_ID", "LAT", "LON"]]
    for _, row in df.iterrows():
        temps = row[month_cols].values.astype(float)
        temps = temps[~np.isnan(temps)]
        if len(temps) > 0:
            std_devs[row["STATION_NAME"]] = round(np.std(temps), 2)
    min_std = min(std_devs.values())
    max_std = max(std_devs.values())
    with open("temperature_stability_stations.txt", "w") as f:
        for station, sd in std_devs.items():
            if sd == min_std:
                f.write(f"Most Stable: {station}: StdDev {sd}°C\n")
        for station, sd in std_devs.items():
            if sd == max_std:
                f.write(f"Most Variable: {station}: StdDev {sd}°C\n")

def main():
    df = load_all_data(temp_folder)
    calculate_seasonal_average(df)
    find_largest_temp_range(df)
    find_temperature_stability(df)

if __name__ == "__main__":
    main()
